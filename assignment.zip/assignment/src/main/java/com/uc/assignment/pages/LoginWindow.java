package com.uc.assignment.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.generic.lib.WebUtility;


public class LoginWindow {

	WebDriver driver;
	WebUtility webUtil;

	public LoginWindow(WebDriver driver){
		this.driver=driver;
		webUtil = new WebUtility(driver);
	}


	private By emailOrMobileTxt = By.cssSelector("form[autocomplete='on'] input[type='text']");
	private By passwordTxt = By.cssSelector("form[autocomplete='on'] input[type='password']");
	private By loginBtn = By.cssSelector("form[autocomplete='on'] button[type='submit']");





	public void performLogin(String email, String password){
		webUtil.fillTextBox(emailOrMobileTxt, email);
		webUtil.fillTextBox(this.passwordTxt, password);
		webUtil.clickElement(loginBtn);
		webUtil.waitTillInvisibilityOfElement(loginBtn);
	}




}
