package com.uc.assignment.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.generic.lib.WebUtility;

public class ProductCategoryListingsPage {

	WebDriver driver;
	WebUtility webUtil;
	int pageNumber;
	String product;

	//By productLnk = By.xpath("//a[@title='"+product+"']");



	public  ProductCategoryListingsPage(WebDriver driver){
		this.driver=driver;
		webUtil = new WebUtility(driver);
	}

	public void navigateToPage(String pageNumber){

		webUtil.clickElement(By.xpath("//nav/a[text()='2']"));
	}

	public void clickOnProductLink(String product){

		webUtil.clickElement(By.xpath("//a[@title='"+product+"']"));
	}

}
