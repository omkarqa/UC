package com.generic.lib;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Drivers {
	WebDriver driver;



	public WebDriver startChrome(){
		String curDir = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", curDir + "/chromedriver.exe");
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();		 
		ChromeOptions options = new ChromeOptions();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		driver = new ChromeDriver(capabilities);
		return driver;
	}




	public void quitDriver(){
		driver.quit();
	}




}
