package com.uc.assignment.testsuite;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;




//import org.testng.annotations.BeforeMethod;
//import org.testng.annotations.Test;
import com.generic.lib.Drivers;
import com.generic.lib.GenericUtility;
import com.generic.lib.WebUtility;
import com.uc.assignment.pages.LoginWindow;
import com.uc.assignment.pages.MenuList;
import com.uc.assignment.pages.MyCartPage;
import com.uc.assignment.pages.ProductCategoryListingsPage;
import com.uc.assignment.pages.ProductCategoryPage;


public class AssignmnetTest {	

	WebDriver driver;
	WebUtility webUtil;
	LoginWindow loginWindow;
	MenuList menuList;
	ProductCategoryListingsPage productListingsPage;
	ProductCategoryPage productCategoryPage;
	MyCartPage myCartPage;
	GenericUtility utility;
	Drivers drivers;

	@Before
	public void before(){
		utility = new GenericUtility();
		drivers = new Drivers();

		driver = drivers.startChrome();
		webUtil = new WebUtility(driver);
		loginWindow = new LoginWindow(driver);
		menuList = new MenuList(driver);
		productListingsPage = new ProductCategoryListingsPage(driver);
		productCategoryPage = new ProductCategoryPage(driver);
		myCartPage = new MyCartPage(driver);
		utility = new GenericUtility();

	}

	@Test
	public void userJourneyAddProduct(){

		driver.get(utility.getConfigProperty("flipkartHomeLiveURL"));
		webUtil.maximizeBrowser();

		loginWindow.performLogin(utility.getConfigProperty("flipkartLoginMobileNumber"), utility.getConfigProperty("flipkarPassword"));
		menuList.hoverToMainMenuListItemMen();	
		menuList.chooseSubCategoryFromMenu("Men", "Sports Shoes");
		productListingsPage.navigateToPage("2");
		productListingsPage.clickOnProductLink("SPRINT AFFECT XTREME LP Running Shoes For Men");
		webUtil.switchTab();
		productCategoryPage.chooseSizeOfProduct(8);
		productCategoryPage.addProductToCart();	
		Assert.assertTrue(myCartPage.isPlaceOrderVisible(), "PlaceOrderIsNotVisible");
		Assert.assertTrue(myCartPage.isProductVisibleOnCartPage("SPRINT AFFECT XTREME LP Running Shoes For Men"), "ProductIsNotVisibleOnCartPage");


	}

	@After
	public void after(){
		drivers.quitDriver();
	}



}
